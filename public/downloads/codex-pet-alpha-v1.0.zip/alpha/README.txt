Codex Pet: alpha / α
====================

日本語
------
このZIPには、αβlabのキャラクター「α」をCodex Petとして使うためのファイルが入っています。

同梱ファイル
------------
- pet.json: Codex Pet用の設定ファイルです。
- spritesheet.webp: 1536 x 1872 px のアニメーション用スプライトシートです。
- TERMS.txt: この配布物の利用条件です。
- CHECKSUMS-SHA256.txt: ファイル確認用のSHA-256チェックサムです。

インストール手順
----------------
1. codex-pet-alpha-v1.0.zip を解凍します。
2. 解凍して出てきた alpha フォルダを ~/.codex/pets/ に入れます。
3. Codexを起動、または再起動します。
4. 表示されない場合は、Codexのアバター/Pet設定から alpha を選択してください。

最終的な配置は次の形です。
~/.codex/pets/alpha/pet.json
~/.codex/pets/alpha/spritesheet.webp

Windowsでは、~/.codex は通常 C:\Users\<ユーザー名>\.codex を指します。

安全性について
--------------
このZIPはオフラインで使うための配布物です。APIキー、トークン、サービスURL、
アカウント情報、メールアドレス、住所、電話番号などの個人情報・機密情報は含めていません。

配布元ページ
------------
https://edenthedoors.com/alphabeta/

English
-------
This package contains the files needed to use α from the αβlab project as a Codex Pet.

Files
-----
- pet.json: Codex Pet metadata.
- spritesheet.webp: 1536 x 1872 px animated pet spritesheet.
- TERMS.txt: Usage terms for this package.
- CHECKSUMS-SHA256.txt: SHA-256 hashes for integrity checks.

Install
-------
1. Unzip codex-pet-alpha-v1.0.zip.
2. Move the extracted alpha folder into ~/.codex/pets/.
3. Start or restart Codex.
4. If it does not appear, select alpha from Codex's avatar/Pet settings.

The final layout should be:
~/.codex/pets/alpha/pet.json
~/.codex/pets/alpha/spritesheet.webp

On Windows, ~/.codex usually means C:\Users\<your-name>\.codex.

Privacy / Security
------------------
This package is intentionally offline-only. It does not include API keys,
tokens, service URLs, account information, email addresses, addresses,
phone numbers, or other personal credentials.
