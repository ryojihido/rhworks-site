﻿# αβlab キャラクター素材パック v2.0
Original character designs: 氷堂リョージ / Ryoji Hido
改訂日 / Revised: 2026-09-15

## v2.0の追加内容
αとβの新たな衣装デザインシート ab_2p.png を追加しました。
従来の4点の画像はそのまま収録しています。

## 収録ファイル / Contents
- a_chara.png
- a_master.png
- b_chara.png
- b_master.png
- ab_2p.png — 追加衣装デザイン / Additional outfit designs (3035 × 2150 px)
- README.txt — この案内 / This guide
- TERMS.txt — 利用規約 v2.0 全文（日本語・英語）/ Full terms in Japanese and English

## ご利用の前に
同梱の TERMS.txt を確認し、同意のうえご利用ください。
個人の非商用での生成AIへの画像入力、画像・動画生成、アレンジ、二次創作、SNS投稿に使えます。
入力先のサービスが規約に従ってデータを学習・改善に利用する場合も、原案者が許諾できる権利の範囲で認めます。
素材そのものの再配布・転売、再配布目的のモデル化（LoRA・Checkpoint等）やデータセット化は禁止です。
商用利用は別途許諾が必要です。第三者の権利や利用するサービスの規約も確認してください。
共有する場合は、素材の再アップロードではなく、公式配布ページへのリンクをご利用ください。
ギャラリーの画像・動画はこの素材パックに含まれません。

## Before use
Please read and agree to the included TERMS.txt.
The pack allows personal, non-commercial AI image input, image/video generation, modifications, fan art, and social posts.
Within the rights the creator can license, service operators may also use that input for training and improvement under their service terms.
Redistribution or resale of the original materials, and creating models (LoRA, Checkpoint, etc.) or datasets for redistribution, are prohibited.
Commercial use requires separate permission. Check third-party rights and the terms of the service you use.
Share the official download page instead of re-uploading the materials.
Gallery images and videos are not included in this pack.

## 公式ページ / Official pages
配布 / Download: https://edenthedoors.com/alphabeta/
利用規約 / Terms: https://edenthedoors.com/alphabeta/guidelines/

クレジットと #αβlab の表示は任意です。/ Credit and the #αβlab hashtag are optional.
